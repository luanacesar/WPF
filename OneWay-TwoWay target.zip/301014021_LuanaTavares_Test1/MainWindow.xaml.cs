﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace _301014021_LuanaTavares_Test1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            Mylife = "HAPPY";
        }

        public string Mylife
        {
            get { return (string)GetValue(MylifeProperty); }
            set { SetValue(MylifeProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Mylife.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty MylifeProperty =
            DependencyProperty.Register("Mylife", typeof(string), typeof(MainWindow), new PropertyMetadata(string.Empty));


    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Collections.ObjectModel;

namespace Group13_Lab2_Comp212
{
    public class Flower
    {
        public string Name { get; set; }
        public string Price { get; set; }

        private double priceInDouble;

        public Flower(string name, double price)
        {
            Name = name;
            this.priceInDouble = price;
            Price = string.Format("${0:0.00}", price);
        }
        public override string ToString()
        {
            return Name + " " + Price;
        }

    }
    public class Fruit
    {
        public string Name;
        public double Price;

        public Fruit(string name, double price)
        {
            this.Name = name;
            this.Price = price;
        }
    } 
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        ObservableCollection<Flower> fl = new ObservableCollection<Flower>();
        ObservableCollection<Fruit> fr = new ObservableCollection<Fruit>();

        public MainWindow()
        {
            InitializeComponent();
            cornerShop();
        }
        public void cornerShop()
        {
            this.flowercombobox.ItemsSource = fl;
            this.fruitcombobox.ItemsSource = fr;

            fl.Add(new Flower("Lilly", 3.49));
            fl.Add(new Flower("Rose", 5.99));
            fl.Add(new Flower("Jasmine", 2.55));
            fl.Add(new Flower("Lotus", 7.49));

            fr.Add(new Fruit("Apple", 1.49));
            fr.Add(new Fruit("Banana", 4.45));
            fr.Add(new Fruit("Orange", 5.99));
            fr.Add(new Fruit("Kiwi", 7.95));


        }

        
    }

}

﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Group13_Lab2_Comp212
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>

    public class Shopping
    {
        public string Name { get; set; }
        public string Price { get; set; }
        private double priceInDouble;

        public Shopping(String name, double price)
        {
            Name = name;
            this.priceInDouble = price;
            Price = string.Format("${0:0.00}", price);
        }
        public double getInDouble()
        {
            return priceInDouble;
        }
        public override string ToString()
        {
            return Name + " " + Price;
        }

    }

    public partial class MainWindow : Window
    {
        double lastNumber;

        ObservableCollection<Shopping> flowers = new ObservableCollection<Shopping>();
        ObservableCollection<Shopping> fruits = new ObservableCollection<Shopping>();
        ObservableCollection<Shopping> shoppingItens = new ObservableCollection<Shopping>();
        public MainWindow()
        {

            InitializeComponent();
            doMyapp();

        }
        public void doMyapp()
        {

            this.flowercombobox.ItemsSource = flowers;
            this.fruitcombobox.ItemsSource = fruits;
            this.dataGrid1.ItemsSource = shoppingItens; // add new list to read the datagrid info


            flowers.Add(new Shopping("Lilly", 40.00));
            flowers.Add(new Shopping("Rose", 30.00));


            fruits.Add(new Shopping("Plum", 15.00));
            fruits.Add(new Shopping("Kiwi", 30.00));
        }

        private void call_reset(object sender, RoutedEventArgs e)
        {
            call_reset_comboboxes(sender, e);
            call_reset_total(sender, e);

            shoppingItens.Clear();


        }

        private void call_flower(object sender, SelectionChangedEventArgs e)
        {
            call_update(sender, e);
        }

        private void call_fruit(object sender, SelectionChangedEventArgs e)
        {

            call_update(sender, e);
        }
        private void call_delete_selected_row(object sender, RoutedEventArgs e)
        {
            double priceInDouble;

            Shopping s = (Shopping)dataGrid1.SelectedItem;
            shoppingItens.Remove(s);
            priceInDouble = shoppingItens.Sum(p => p.getInDouble());
            total.Text = string.Format("${0:0.00}", priceInDouble);
          


        }
        private void call_reset_comboboxes(object sender, RoutedEventArgs e)
        {
            fruitcombobox.IsEditable = true;
            fruitcombobox.IsReadOnly = true;
            fruitcombobox.Text = "Pick a Fruit";

            flowercombobox.IsEditable = true;
            flowercombobox.IsReadOnly = true;
            flowercombobox.Text = "Pick a flower";
        }


        private void call_reset_total(object sender, RoutedEventArgs e)
        {
            total.Text = "0";

        }

        private void call_update(object sender, SelectionChangedEventArgs e)
        {
            var item = (sender as ComboBox).SelectedItem;
            if (item == null) return;

            Shopping s = (Shopping)item;
            shoppingItens.Add(new Shopping(s.Name, s.getInDouble()));

            double priceInDouble;
            priceInDouble = shoppingItens.Sum(p => p.getInDouble());
            total.Text = string.Format("${0:0.00}", priceInDouble);
        }

    }
}
